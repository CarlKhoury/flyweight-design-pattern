package ui.settings;

import java.net.URL;
import java.util.ResourceBundle;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

public class SettingsController implements Initializable{
	
	User user;

    @FXML
    private AnchorPane mainPane;
	@FXML
	private TextField username;
	@FXML
	private PasswordField password;

	// Event Listener on Button.onAction
	@FXML
	public void saveAction(ActionEvent event) {
		String uName = username.getText();
		String pass = password.getText();
		if(uName.equals(user.getUsername()) && pass.equals(user.getPassword())) {
			Alert alert = new Alert(Alert.AlertType.ERROR);
			alert.setHeaderText(null);
			alert.setContentText("You already have the same username and password");
			alert.showAndWait();
			return;
		} else {
			user.setUsername(uName);
			user.setPassword(pass);
			exitStage();
		}
		
	}
	// Event Listener on Button.onAction
	@FXML
	public void cancelAction(ActionEvent event) {
		exitStage();
	}
	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		user = User.getInformation();
	}
	
	private void exitStage() {
    	Stage stage = (Stage)(mainPane.getScene().getWindow());
    	stage.close();
    }
}
