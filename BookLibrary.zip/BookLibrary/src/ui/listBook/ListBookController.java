package ui.listBook;

import java.io.File;
import java.io.FileNotFoundException;
import java.net.URL;
import java.util.ResourceBundle;
import java.util.Scanner;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.ListView;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import ui.addBook.Book;

public class ListBookController implements Initializable{
	
	private static File srcFile = new File("books.txt");
	
	private static ObservableList<String> bookList = FXCollections.observableArrayList();
	
	@FXML
	private AnchorPane mainPane;
    @FXML
    private ListView<String> booksList;

    @FXML
    void back(ActionEvent event) {
    	Stage stage = (Stage)(mainPane.getScene().getWindow());
    	stage.close();
    }


	private void loadData() {
//		Iterator<Book> iterator = bookList.iterator();
//		String books = "";
//		while(iterator.hasNext()) {
//			books.concat(iterator.next().toString());
//		}
//		System.out.println(books);
		booksList.getItems().addAll(bookList);
	}

	private void loadList() throws FileNotFoundException {
		Scanner scan = new Scanner(srcFile);
		while(scan.hasNextLine()) {
			Book book = new Book(scan.nextLine(), scan.nextLine(), scan.nextLine(), scan.nextLine(), scan.nextBoolean());
			bookList.add(book.getId());
			scan.nextLine();
		}
		System.out.println(bookList);
		scan.close();
	}

	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		try {
			loadList();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		loadData();		
	}

}
